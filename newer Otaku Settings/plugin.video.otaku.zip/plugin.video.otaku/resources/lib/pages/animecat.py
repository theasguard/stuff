import json
import re
from bs4 import BeautifulSoup, SoupStrainer
from six.moves import urllib_parse

from resources.lib.ui import control, database
from resources.lib.ui.BrowserBase import BrowserBase
from resources.lib.indexers.malsync import MALSYNC

import xbmc
import xbmcaddon

# Get addon handle for logging
addon = xbmcaddon.Addon()

class sources(BrowserBase):
    _BASE_URL = 'https://watch.hikaritv.xyz/'

    def get_sources(self, anilist_id, episode, get_backup):
        show = database.get_show(anilist_id)
        title = show.get('name')
        keyword = title

        all_results = []
        srcs = ['sub', 'dub']
        if control.getSetting('general.source') == 'Sub':
            srcs.remove('dub')
        elif control.getSetting('general.source') == 'Dub':
            srcs.remove('sub')

        items = MALSYNC().get_slugs(anilist_id=anilist_id, site='Hikari')
        if not items:
            # If no matching title found in MALSYNC, try searching on Hikari
            headers = {'Referer': self._BASE_URL}
            params = {'keyword': keyword}
            res = database.get(
                self._get_request,
                8,
                self._BASE_URL + 'search',
                data=params,
                headers=headers
            )

            # Find anime slugs on search results page
            mlink = SoupStrainer('div', {'class': 'flw-item'})
            mdiv = BeautifulSoup(res, "html.parser", parse_only=mlink)
            sitems = []
            for sdiv in mdiv.find_all('div', class_='thumb'):
                try:
                    slug = sdiv.find('a').get('href').split('/')[-1]
                    stitle = sdiv.find('a').get('title')
                    sitems.append({'title': stitle, 'slug': slug})
                except AttributeError:
                    pass

            # Try to match anime based on title and possible year
            if sitems:
                if title[-1].isdigit():
                    items = [x.get('slug') for x in sitems if title.lower() in x.get('title').lower()]
                else:
                    items = [x.get('slug') for x in sitems if (title.lower() + ' ') in (x.get('title').lower() + ' ')]
                if not items and ':' in title:
                    title = title.split(':')[0]
                    items = [x.get('slug') for x in sitems if (title.lower() + ' ') in (x.get('title').lower() + ' ')]

        if items:
            slug = items[0]
            all_results = self._process_hikaritv(slug, title=title, episode=episode, langs=srcs)

        return all_results

    def _process_hikaritv(self, slug, title, episode, langs):
        sources = []
        headers = {'Referer': self._BASE_URL}

        # Log the slug and episode we are working with
        addon.log(f"Hikari: Processing slug {slug}, episode {episode}", xbmc.LOGDEBUG)

        try:
            # Get episode list
            res = database.get(
                self._get_request,
                8,
                f'{self._BASE_URL}anime/{slug}',
                headers=headers
            )
            soup = BeautifulSoup(res, "html.parser")

            # Find episode links more robustly 
            episode_links = soup.find_all('a', {'href': re.compile(rf'/{slug}/episode-{episode}$')})  

            for episode_link in episode_links:
                episode_url = episode_link.get('href')
                addon.log(f"Hikari: Found episode URL: {episode_url}", xbmc.LOGDEBUG)

                res = database.get(
                    self._get_request,
                    8,
                    f'{self._BASE_URL}{episode_url}',
                    headers=headers
                )
                soup = BeautifulSoup(res, "html.parser")

                # Find the iframe with data-src attribute
                iframe = soup.find('iframe', attrs={'data-src': True})
                if iframe:
                    embed_url = iframe.get('data-src')
                    addon.log(f"Hikari: Found embed URL: {embed_url}", xbmc.LOGDEBUG)

                    res = database.get(
                        self._get_request,
                        8,
                        embed_url,
                        headers=headers
                    )
                    soup = BeautifulSoup(res, 'html.parser')

                    # Find the iframe inside the player div
                    player_link = soup.find('div', class_='player')
                    if player_link:
                        embed_link = player_link.find('iframe').get('src')
                        addon.log(f"Hikari: Found final embed link: {embed_link}", xbmc.LOGDEBUG)

                        source = {
                            'release_title': f'{title} - Ep {episode}',
                            'hash': embed_link,
                            'type': 'embed',
                            'quality': 'HD',
                            'debrid_provider': '',
                            'provider': 'animecat', # File name should be hikaritv.py
                            'size': 'NA',
                            'info': ['SUB' if langs == 'sub' else 'DUB'],
                            'lang': 2 if langs == 'dub' else 0,
                        }
                        sources.append(source)
                else:
                    addon.log("Hikari: Could not find iframe with data-src", xbmc.LOGERROR)

        except Exception as e:
            addon.log(f"Hikari: Error processing sources: {e}", xbmc.LOGERROR)

        return sources