
import re
import json
import pickle

from bs4 import BeautifulSoup, SoupStrainer
from resources.lib.ui import control, database, source_utils
from resources.lib.ui.BrowserBase import BrowserBase
from urllib.parse import urljoin

class sources(BrowserBase):
    _BASE_URL = 'https://w7.animeland.tv'

    def get_sources(self, anilist_id, episode, get_backup):
        show = database.get_show(anilist_id)
        kodi_meta = pickle.loads(show.get('kodi_meta'))
        title = kodi_meta.get('name')
        title = self._clean_title(title)  # Assuming _clean_title is defined

        headers = {'Referer': self._BASE_URL}
        search_url = self.get_search_url(title)

        soup = self._get_soup(search_url, headers=headers)
        show_url = self._get_show_url(soup, title)

        if not show_url:
            return []

        return self._process_show(show_url, title, episode)

    def get_search_url(self, query):
        return '%s/?s=%s' % (self._BASE_URL, query)

    def _clean_title(self, title):
        title = title.replace('(', '')
        title = title.replace(')', '')
        title = title.replace('&', 'and')
        title = title.replace('  ', ' ')
        return title.strip().lower()

    def _get_soup(self, url, headers=None):
        html = self._get_request(url, headers=headers)
        return BeautifulSoup(html, 'html.parser')

    def _get_show_url(self, soup, title):
        for result in soup.select('.search-page article'):
            a = result.select_one('.entry-title a')
            if a and self._clean_title(a.text) == title:
                return urljoin(self._BASE_URL, a['href'])  # Use urljoin to build absolute URL
        return None

    def _process_show(self, show_url, title, episode):
        sources = []
        soup = self._get_soup(show_url)
        image_url = soup.select_one('div.imagen img')['src']
        image = urljoin(self._BASE_URL, image_url) if image_url.startswith('/') else image_url  # Build absolute image URL 

        for episode_link in soup.select('.episodios li a'):
            if f"Episode {episode}" in episode_link.text:
                episode_url = urljoin(self._BASE_URL, episode_link['href'])  # Use urljoin 
                sources.extend(self._process_episode(episode_url, title, episode, image))
        return sources

    def _process_episode(self, episode_url, title, episode, image):
        sources = []
        soup = self._get_soup(episode_url)

        # Extract sources from the JavaScript variables
        script_content = soup.find('script', text=re.compile('window.HDPlayerSrc')).text
        hd_player_src = re.search(r"window\.HDPlayerSrc\s*=\s*'([^']+)'", script_content).group(1)
        main_player_src = re.search(r"window\.MainPlayerSrc\s*=\s*'([^']+)'", script_content).group(1)

        sources.append(self._create_source(hd_player_src, title, episode, image, '4K'))
        sources.append(self._create_source(main_player_src, title, episode, image, '1080p'))

        return sources

    def _create_source(self, url, title, episode, image, quality):
        return {
            'release_title': '{0} - Ep {1}'.format(title, episode),
            'hash': url,
            'type': 'embed',
            'quality': quality,
            'debrid_provider': '',
            'provider': 'animeland',
            'size': 'NA',
            'info': [],
            'lang': 2 if 'dub' in title.lower() else 0
        }
