import re
import itertools
import pickle
import xbmc
import six
import json

from functools import partial
from bs4 import BeautifulSoup, SoupStrainer
from resources.lib.ui.BrowserBase import BrowserBase
from resources.lib.ui import database, source_utils, client
from resources.lib import debrid
from six.moves import urllib_parse

import logging

logging.basicConfig(level=logging.DEBUG)


headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Android SDK built for x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Mobile Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.8',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'DNT': '1',
    'Proxy-Connection': 'keep-alive',
}

class sources(BrowserBase):
    _BASE_URL = 'https://anidex.info'

    def get_sources(self, query, anilist_id, episode, status, media_type, rescrape):
        show = database.get_show(anilist_id)
        logging.debug("Retrieved show from database: %s", show)
        kodi_meta = pickle.loads(show.get('kodi_meta'))
        logging.debug("Kodi meta: %s", kodi_meta)
        show_meta = database.get_show_meta(anilist_id)

        query, season = self._build_query(kodi_meta, anilist_id, episode, media_type)
        logging.debug("Final query string: %s", query)

        anidb = self._get_anidb_id(anilist_id, show_meta)
        content_type_ids = '1,2,3'
        url = self._build_url(query, anidb, content_type_ids)
        logging.debug("URL string: %s", url)

        html = client.request(url, timeout=60)
        soup = BeautifulSoup(html, "html.parser", parse_only=SoupStrainer('div', {'class': 'table-responsive'}))

        list_ = self._parse_torrents(soup)
        logging.debug("List structure: %s", list_)

        filtered_list = self._filter_torrents(list_, season, episode)
        logging.debug("Filtered List: %s", filtered_list)
        cache_list = debrid.TorrentCacheCheck().torrentCacheCheck(filtered_list)
        cache_list = sorted(cache_list, key=lambda k: k['downloads'], reverse=True)
        mapfunc = partial(self._parse_anidex_view, episode=episode)
        all_results = list(map(mapfunc, cache_list))
        return all_results

    def _build_query(self, kodi_meta, anilist_id, episode, media_type):
        query = kodi_meta.get('ename')
        logging.debug("Title: %s", query)
        query = self._clean_title(query)
        logging.debug("Cleaned query string: %s", query)

        # Ensure season is defined
        season = None
        if media_type != "movie":
            season = database.get_season_list(anilist_id)['season']
            season = str(season).zfill(2)
            query_template = "{title} S{season}E{episode}"
            query = query_template.format(title=query, season=season, episode=episode.zfill(2))
            logging.debug("Query string for series: %s", query)
        else:
            query_template = "{title} - {episode}"
            query = query_template.format(title=query, episode=episode.zfill(2))
            logging.debug("Query string for movie: %s", query)

        return query, season

    def _get_anidb_id(self, anilist_id, show_meta):
        show_meta = database.get_show_meta(anilist_id)
        anidb = database.get_anidb_id(anilist_id)
        if anidb is None and show_meta:
            meta_ids = pickle.loads(show_meta['meta_ids'])
            anidb = meta_ids.get('anidb')
        return anidb

    def _build_url(self, query, content_type_ids):
        return '%s/?q=%s&id=%s' % (self._BASE_URL, urllib_parse.quote_plus(query), content_type_ids)

    def _parse_torrents(self, soup):
        list_ = []
        for row in soup.select('table.table tbody tr'):
            torrent_link = row.select_one('td:nth-of-type(3) a.torrent')
            magnet_link = row.select_one('td:nth-of-type(6) a')
            size_cell = row.select_one('td:nth-of-type(7)')
            download_link = row.select_one('td:nth-of-type(5) a')

            # Extract the name from the span inside the a.torrent tag
            name = torrent_link.select_one('span').get('title', 'No name available') if torrent_link else 'No name available'

            torrent_data = {
                'name': name,
                'magnet': magnet_link.get('href', 'No magnet link available') if magnet_link else 'No magnet link available',
                'size': size_cell.get_text(strip=True) if size_cell else 'No size available',
                'torrent_link': download_link.get('href', 'No torrent link available') if download_link else 'No torrent link available'
            }
            list_.append(torrent_data)
        return list_

    def _filter_torrents(self, list_, season, episode):
        regex = r'Season\s*(\d+)\s*Episode\s*(\d+)|S(\d+)E(\d+)|(\d+)x(\d+)'
        regex_ep = r'\de(\d+)\b|\se(\d+)\b|\s-\s(\d{1,4})\b'
        rex = re.compile(regex)
        rex_ep = re.compile(regex_ep)

        filtered_list = []
        for torrent in list_:
            if 'magnet' in torrent and torrent['magnet']:
                try:
                    torrent['hash'] = re.findall(r'btih:(.*?)(?:&|$)', torrent['magnet'])[0]
                except IndexError:
                    continue  # Handle the case where no match is found

            title = torrent['name'].lower()
            ep_match = rex_ep.findall(title)
            ep_match = list(map(int, list(filter(None, itertools.chain(*ep_match)))))

            if ep_match and ep_match[0] != int(episode):
                regex_ep_range = r'\s(?:\d+(?:[-~]\d+)?)(?:-(?:\d+(?:[-~]\d+)?))?'
                rex_ep_range = re.compile(regex_ep_range)

                if not rex_ep_range.search(title):
                    continue

            match = rex.findall(title)
            match = list(map(int, list(filter(None, itertools.chain(*match)))))
            if not match or (season and match[0] == int(season)):
                filtered_list.append(torrent)
            elif not season:
                filtered_list.append(torrent)

        return filtered_list


    def _parse_anidex_view(self, res, episode):
        source = {
            'release_title': res.get('name'),
            'hash': res.get('hash'),
            'type': 'torrent',
            'quality': source_utils.getQuality(res.get('name')),
            'debrid_provider': res.get('debrid_provider'),
            'provider': 'anidex',
            'episode_re': episode,
            'size': res.get('size'),
            'info': source_utils.getInfo(res.get('name')),
            'lang': source_utils.getAudio_lang(res.get('name'))
        }
        return source

# # Example Usage:
# list_ = [
    # {'name': '[SubsPlus+] Helck - S01E05 (WEB 1080p ADN)', 'magnet': 'magnet:?xt=urn:btih:KUBWMN4S2NXSAYUT5JBMYWHUY56Y4BLU&tr=http://anidex.moe:6969/announce', 'size': '532 MB', 'download_link': '/dl/565614'},
    # # Add more torrent data here for testing
# ]
# season = '01'
# episode = '05'
# filtered_torrents = self._filter_torrents(list_, season, episode)
# print(filtered_torrents)